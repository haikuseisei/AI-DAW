# Phase 1 アーキテクチャ設計

**基盤**: Tauri v2 + React + Rust
**目標**: MVPスコープの全機能を搭載した動作するデスクトップアプリ

---

## 1. プロジェクト構造

```
app/
├── src-tauri/                    # Rust バックエンド
│   ├── src/
│   │   ├── main.rs               # Tauriエントリーポイント
│   │   ├── audio/
│   │   │   ├── mod.rs
│   │   │   ├── engine.rs          # オーディオエンジン（cpal）
│   │   │   ├── synth.rs           # シンプルシンセ
│   │   │   ├── recorder.rs        # オーディオ録音
│   │   │   └── playback.rs        # マルチトラック再生
│   │   ├── midi/
│   │   │   ├── mod.rs
│   │   │   ├── engine.rs          # MIDIデータ処理
│   │   │   ├── io.rs              # MIDI デバイスI/O（midir）
│   │   │   └── file.rs            # MIDI ファイル読み書き
│   │   ├── ai/
│   │   │   ├── mod.rs
│   │   │   ├── client.rs          # Claude API クライアント
│   │   │   ├── transcribe.rs      # 採譜（Basic Pitch連携）
│   │   │   ├── chord.rs           # コード検出
│   │   │   ├── session.rs         # セッション生成（ピンポン/パート提案）
│   │   │   └── lyrics.rs          # 歌詞補助
│   │   ├── project/
│   │   │   ├── mod.rs
│   │   │   ├── state.rs           # プロジェクト状態管理
│   │   │   ├── track.rs           # トラックデータ構造
│   │   │   └── file.rs            # プロジェクトファイル保存/読込
│   │   └── commands.rs            # Tauri IPC コマンド定義
│   ├── Cargo.toml
│   └── tauri.conf.json
├── src/                           # React フロントエンド
│   ├── App.jsx
│   ├── main.jsx
│   ├── stores/
│   │   ├── projectStore.js        # プロジェクト状態（Zustand）
│   │   ├── transportStore.js      # 再生/録音状態
│   │   └── sessionStore.js        # AIセッション状態
│   ├── components/
│   │   ├── Timeline/
│   │   │   ├── Timeline.jsx       # メインタイムライン
│   │   │   ├── Track.jsx          # 個別トラック表示
│   │   │   ├── TrackHeader.jsx    # トラック名/ミュート/ソロ
│   │   │   └── Cursor.jsx         # 再生カーソル
│   │   ├── PianoRoll/
│   │   │   ├── PianoRoll.jsx      # ピアノロールエディタ
│   │   │   ├── NoteGrid.jsx       # ノートグリッド（Canvas）
│   │   │   ├── KeyboardSidebar.jsx
│   │   │   └── VelocityLane.jsx   # ベロシティ編集
│   │   ├── Session/
│   │   │   ├── SessionPanel.jsx   # セッションモード切替
│   │   │   ├── PingPong.jsx       # ピンポン共作UI
│   │   │   └── PartSuggest.jsx    # 別パート提案UI
│   │   ├── Lyrics/
│   │   │   ├── LyricsEditor.jsx   # 歌詞エディタ
│   │   │   └── LyricsSuggest.jsx  # 歌詞提案パネル
│   │   ├── Chords/
│   │   │   ├── ChordDisplay.jsx   # コード進行表示
│   │   │   └── ChordSuggest.jsx   # コード提案
│   │   ├── Transport/
│   │   │   └── TransportBar.jsx   # 再生/録音/BPM
│   │   └── shared/
│   │       ├── Waveform.jsx       # 波形表示（Canvas）
│   │       └── MidiClip.jsx       # MIDIクリップ表示
│   ├── hooks/
│   │   ├── useAudio.js            # オーディオエンジンIPC
│   │   ├── useMidi.js             # MIDIデバイスIPC
│   │   └── useAI.js               # AI機能IPC
│   └── styles/
│       └── global.css
├── package.json
└── vite.config.js
```

---

## 2. レイヤー構成

```
┌─────────────────────────────────────────────┐
│              React フロントエンド              │
│  Timeline / PianoRoll / Session / Lyrics     │
├──────────────── Tauri IPC ──────────────────┤
│               Rust バックエンド                │
│  ┌──────────┐ ┌──────────┐ ┌──────────────┐ │
│  │ Audio    │ │ MIDI     │ │ AI           │ │
│  │ Engine   │ │ Engine   │ │ Client       │ │
│  │ (cpal)   │ │ (midir)  │ │ (reqwest)    │ │
│  └──────────┘ └──────────┘ └──────────────┘ │
│  ┌──────────────────────────────────────────┐│
│  │         Project State (serde/JSON)       ││
│  └──────────────────────────────────────────┘│
└─────────────────────────────────────────────┘
```

**フロントエンド → バックエンド 通信**:
- Tauri の `invoke` コマンドでRust関数を呼び出す
- オーディオ/MIDIのリアルタイムデータはTauriイベントで非同期にフロントへ送る
- AI呼び出しは非同期コマンド（数秒かかるためフロントをブロックしない）

---

## 3. コアデータ構造

### 3.1 プロジェクト

```rust
// src-tauri/src/project/state.rs

pub struct Project {
    pub name: String,
    pub bpm: f64,
    pub time_signature: (u8, u8),  // (numerator, denominator)
    pub tracks: Vec<Track>,
    pub session: SessionState,
}

pub struct Track {
    pub id: Uuid,
    pub name: String,
    pub kind: TrackKind,
    pub clips: Vec<Clip>,
    pub muted: bool,
    pub solo: bool,
    pub volume: f32,       // 0.0 - 1.0
    pub pan: f32,          // -1.0 (L) to 1.0 (R)
    pub source: NoteSource,
}

pub enum TrackKind {
    Midi { instrument: Instrument },
    Audio,
}

pub enum NoteSource {
    Human,
    AI,
    Mixed,
}

pub struct Clip {
    pub id: Uuid,
    pub start_beat: f64,
    pub duration_beats: f64,
    pub content: ClipContent,
}

pub enum ClipContent {
    Midi(Vec<MidiNote>),
    Audio(AudioBuffer),
}

pub struct MidiNote {
    pub pitch: u8,          // 0-127
    pub start_beat: f64,    // ビート単位の開始位置
    pub duration_beats: f64,
    pub velocity: u8,       // 0-127
    pub source: NoteSource,
}
```

### 3.2 セッション状態

```rust
// src-tauri/src/project/state.rs

pub struct SessionState {
    pub mode: SessionMode,
    pub current_section: usize,
    pub section_length_bars: usize,  // default 4
    pub history: Vec<SessionEntry>,
}

pub enum SessionMode {
    PingPong,       // 交互に書く
    PartSuggest,    // AIが別パートを提案
    Off,
}

pub struct SessionEntry {
    pub section: usize,
    pub source: NoteSource,
    pub note_count: usize,
    pub timestamp: DateTime<Utc>,
}
```

---

## 4. オーディオエンジン

### 4.1 構成

```rust
// src-tauri/src/audio/engine.rs

use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};

pub struct AudioEngine {
    stream: Option<cpal::Stream>,
    sample_rate: u32,
    buffer_size: u32,         // 256 samples = ~5.8ms at 44100Hz
    mixer: Arc<Mutex<Mixer>>,
}

pub struct Mixer {
    pub tracks: Vec<TrackPlayback>,
    pub master_volume: f32,
    pub position_samples: u64,  // 現在再生位置
    pub bpm: f64,
    pub playing: bool,
}
```

### 4.2 シンセ（MVP用の簡易版）

MVP段階ではVST/AUプラグインは不要。以下のビルトインシンセで十分:

- **リードシンセ**: ノコギリ波 + ローパスフィルタ + ADSR エンベロープ
- **ベースシンセ**: 矩形波 + ローパスフィルタ
- **ドラム**: サンプルベース（キック/スネア/ハイハット/タム）、組み込みWAV
- **パッド**: 三角波 × 2（デチューン）+ リバーブ

Phase 2以降でVST3/サウンドフォント対応を追加。

### 4.3 録音

```rust
// src-tauri/src/audio/recorder.rs

pub struct Recorder {
    buffer: Vec<f32>,
    is_recording: bool,
    input_device: cpal::Device,
}
```

入力デバイスからの録音 → WAVバッファ → 採譜エンジンに渡す or オーディオトラックに配置。

---

## 5. AI統合

### 5.1 クライアント

```rust
// src-tauri/src/ai/client.rs

pub struct AIClient {
    api_key: String,       // ユーザーが設定画面で入力
    base_url: String,      // https://api.anthropic.com
    model: String,          // claude-sonnet-4-20250514
}

impl AIClient {
    pub async fn generate(&self, prompt: &str) -> Result<String> {
        // reqwest で Claude API を呼び出し
    }
}
```

### 5.2 セッション生成

```rust
// src-tauri/src/ai/session.rs

/// ピンポン共作: ユーザーのノートを受け取り、続きを生成
pub async fn generate_continuation(
    client: &AIClient,
    existing_notes: &[MidiNote],
    section_start: f64,
    section_end: f64,
    context: &SessionContext,  // BPM, キー, ジャンルヒント等
) -> Result<Vec<MidiNote>>

/// 別パート提案: 既存トラックを受け取り、別パートを生成
pub async fn suggest_part(
    client: &AIClient,
    existing_tracks: &[Track],
    target_instrument: Instrument,  // Bass, Drums, Keys, Strings...
    section_range: (f64, f64),
) -> Result<Vec<MidiNote>>
```

### 5.3 採譜

モノフォニック採譜はRust内でPython連携（PyO3）またはONNX Runtimeで推論:

- **選択肢A**: PyO3でBasic Pitchを呼ぶ（確実だが依存が重い）
- **選択肢B**: Basic PitchのONNXモデルをRust側で推論（軽量だが実装工数）
- **選択肢C**: クラウドAPIに音声を送り、サーバー側で採譜（最も軽量、レイテンシ大）

MVP推奨: **選択肢C**。クラウドAPIに音声をBase64で送り、サーバー側で処理。ローカル推論はPhase 2で。

### 5.4 コード検出

ルールベース実装（Phase 0のものをRustに移植）で十分。MIDIノートからピッチクラスを抽出し、トライアドやセブンスを照合。

---

## 6. Tauri IPCコマンド一覧

```rust
// src-tauri/src/commands.rs

// --- プロジェクト ---
#[tauri::command] fn new_project(name: &str) -> Project;
#[tauri::command] fn save_project(path: &str) -> Result<()>;
#[tauri::command] fn load_project(path: &str) -> Result<Project>;

// --- トラック ---
#[tauri::command] fn add_track(kind: TrackKind) -> Track;
#[tauri::command] fn remove_track(track_id: Uuid);
#[tauri::command] fn update_track(track_id: Uuid, updates: TrackUpdate);

// --- ノート編集 ---
#[tauri::command] fn add_note(track_id: Uuid, note: MidiNote);
#[tauri::command] fn remove_note(track_id: Uuid, note_id: Uuid);
#[tauri::command] fn update_note(track_id: Uuid, note_id: Uuid, updates: NoteUpdate);
#[tauri::command] fn get_notes(track_id: Uuid, range: (f64, f64)) -> Vec<MidiNote>;

// --- トランスポート ---
#[tauri::command] fn play();
#[tauri::command] fn stop();
#[tauri::command] fn set_bpm(bpm: f64);
#[tauri::command] fn set_position(beat: f64);
#[tauri::command] fn start_recording(track_id: Uuid);
#[tauri::command] fn stop_recording() -> Vec<f32>;  // 録音バッファを返す

// --- AI ---
#[tauri::command] async fn ai_set_api_key(key: String);
#[tauri::command] async fn ai_ping_pong(notes: Vec<MidiNote>, section: SectionRange, ctx: SessionContext) -> Vec<MidiNote>;
#[tauri::command] async fn ai_suggest_part(tracks: Vec<Track>, instrument: Instrument, range: SectionRange) -> Vec<MidiNote>;
#[tauri::command] async fn ai_detect_chords(notes: Vec<MidiNote>) -> Vec<ChordLabel>;
#[tauri::command] async fn ai_transcribe(audio: Vec<u8>) -> Vec<MidiNote>;
#[tauri::command] async fn ai_lyrics_suggest(context: LyricsContext) -> Vec<String>;

// --- MIDI デバイス ---
#[tauri::command] fn list_midi_devices() -> Vec<MidiDeviceInfo>;
#[tauri::command] fn connect_midi_input(device_id: usize);
```

---

## 7. Rustクレート依存

```toml
# src-tauri/Cargo.toml

[dependencies]
tauri = { version = "2", features = ["shell-open"] }
serde = { version = "1", features = ["derive"] }
serde_json = "1"
uuid = { version = "1", features = ["v4", "serde"] }
tokio = { version = "1", features = ["full"] }
reqwest = { version = "0.12", features = ["json"] }
chrono = { version = "0.4", features = ["serde"] }

# Audio
cpal = "0.15"
hound = "3"              # WAV読み書き
dasp = "0.11"            # DSPユーティリティ

# MIDI
midir = "0.10"           # MIDIデバイスI/O
midly = "0.5"            # MIDIファイルパース

# Serialization
bincode = "1"            # プロジェクトファイル用バイナリシリアライズ
```

---

## 8. フロントエンドパッケージ

```json
{
  "dependencies": {
    "react": "^18",
    "react-dom": "^18",
    "@tauri-apps/api": "^2",
    "zustand": "^4",
    "immer": "^10"
  },
  "devDependencies": {
    "vite": "^5",
    "@vitejs/plugin-react": "^4",
    "tailwindcss": "^3"
  }
}
```

Zustandを状態管理に使う理由: Redux的なボイラープレートなしで、Reactの外からも状態更新できる（オーディオコールバックからの再生位置更新等）。

---

## 9. 開発ロードマップ（Phase 1内の段階）

### Step 1: スケルトン（1-2週間）
- Tauri v2 + React + Viteプロジェクトのセットアップ
- cpalでオーディオ出力確認（テストトーン再生）
- Tauri IPC の基本疎通確認

### Step 2: DAW基盤（2-3週間）
- プロジェクト/トラック/ノートのデータ構造実装
- タイムライン表示（トラック一覧、再生カーソル）
- ピアノロール（Canvas描画、クリックでノート配置/削除）
- トランスポート（再生/停止/BPM設定）
- ビルトインシンセ（リード、ベース、ドラム）
- Phase 0のピアノロール体験をネイティブ品質に昇華

### Step 3: AI統合（1-2週間）
- Claude APIクライアント実装
- ピンポン共作（Phase 0の移植 + 改善）
- 別パート提案（ベース/ドラムをAIが提案）
- コード検出（ルールベース移植）

### Step 4: 録音と採譜（1-2週間）
- マイク録音（cpal入力）
- 録音→クラウドAPI採譜
- 採譜結果をMIDIトラックに配置

### Step 5: 歌詞と仕上げ（1週間）
- 歌詞エディタ（テキスト入力、タイムライン同期は後回し）
- 歌詞提案（Claude API）
- プロジェクト保存/読込
- エクスポート（WAV書き出し）

### 合計目安: 7-10週間（個人開発）

---

## 10. Phase 0から引き継ぐもの

| Phase 0の実装 | Phase 1での扱い |
|--------------|----------------|
| ピアノロールUI | Canvas描画に作り直し（パフォーマンス向上） |
| ノート配置/削除のインタラクション | 維持、ドラッグ選択/移動を追加 |
| コード検出ロジック | Rustに移植 |
| Claude APIプロンプト設計 | Rust側のai::sessionに移植、プロンプト改善 |
| Web Audio シンセ | cpal + Rustシンセに置き換え |
| ピンポンの交互ターン制御 | sessionStore + Rust側SessionStateに分離 |

---

## 11. 未決定（Phase 1開始前に判断不要、開発中に決める）

| 項目 | 決定タイミング |
|------|--------------|
| MIDIデバイス対応の優先度 | Step 2終了時 |
| オーディオ録音のフォーマット（WAV/FLAC） | Step 4開始時 |
| プロジェクトファイル形式の詳細 | Step 5開始時 |
| ショートカットキー体系 | Step 2で基本のみ、以降追加 |
