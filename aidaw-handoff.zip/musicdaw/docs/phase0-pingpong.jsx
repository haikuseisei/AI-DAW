import { useState, useRef, useCallback, useEffect } from "react";

const BARS = 16;
const BEATS_PER_BAR = 4;
const TOTAL_BEATS = BARS * BEATS_PER_BAR;
const SECTION_BARS = 4;
const SECTION_BEATS = SECTION_BARS * BEATS_PER_BAR;
const NUM_SECTIONS = BARS / SECTION_BARS;
const MIN_PITCH = 48; // C3
const MAX_PITCH = 72; // C5
const PITCH_COUNT = MAX_PITCH - MIN_PITCH;
const NOTE_NAMES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
const BPM_DEFAULT = 120;

const pitchToName = (p) => {
  const oct = Math.floor(p / 12) - 1;
  return `${NOTE_NAMES[p % 12]}${oct}`;
};

const isBlackKey = (p) => [1,3,6,8,10].includes(p % 12);

// Simple chord detection from notes in a bar
const detectChord = (notes, barStart) => {
  const barEnd = barStart + BEATS_PER_BAR;
  const pcs = [...new Set(
    notes.filter(n => n.beat >= barStart && n.beat < barEnd).map(n => n.pitch % 12)
  )].sort((a,b) => a - b);
  if (pcs.length < 2) return pcs.length === 1 ? NOTE_NAMES[pcs[0]] : "";
  
  for (let i = 0; i < pcs.length; i++) {
    const root = pcs[i];
    const intervals = pcs.map(p => (p - root + 12) % 12).sort((a,b) => a - b);
    const key = intervals.join(",");
    const name = NOTE_NAMES[root];
    if (key === "0,4,7") return name;
    if (key === "0,3,7") return name + "m";
    if (key === "0,4,7,11") return name + "maj7";
    if (key === "0,4,7,10") return name + "7";
    if (key === "0,3,7,10") return name + "m7";
    if (key === "0,3,6") return name + "dim";
    if (key === "0,4,8") return name + "aug";
    if (key === "0,5,7") return name + "sus4";
    if (key === "0,2,7") return name + "sus2";
  }
  return NOTE_NAMES[pcs[0]] + "?";
};

// Web Audio synth
const createSynth = () => {
  let ctx = null;
  const activeNotes = new Map();
  
  const getCtx = () => {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    return ctx;
  };
  
  const playNote = (pitch, duration = 0.2, source = "human") => {
    const c = getCtx();
    const freq = 440 * Math.pow(2, (pitch - 69) / 12);
    const osc = c.createOscillator();
    const gain = c.createGain();
    const filter = c.createBiquadFilter();
    
    osc.type = source === "ai" ? "triangle" : "sawtooth";
    osc.frequency.value = freq;
    filter.type = "lowpass";
    filter.frequency.value = source === "ai" ? 2000 : 3000;
    filter.Q.value = 1;
    
    gain.gain.setValueAtTime(0.15, c.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + duration);
    
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(c.destination);
    osc.start(c.currentTime);
    osc.stop(c.currentTime + duration + 0.05);
  };
  
  return { playNote, getCtx };
};

// AI generation via Claude API
const generateContinuation = async (allNotes, sectionStart, sectionEnd) => {
  const context = allNotes.filter(n => n.beat < sectionStart);
  const prompt = `You are a music composition collaborator. The user has written notes and now it's your turn to write the next ${SECTION_BARS} bars (beats ${sectionStart} to ${sectionEnd - 1}).

Here are ALL notes written so far (pitch = MIDI note number ${MIN_PITCH}-${MAX_PITCH - 1}, beat = beat position, source = who wrote it):
${JSON.stringify(context, null, 1)}

Rules:
- Write a musically coherent continuation that responds to what came before
- Use pitches ${MIN_PITCH}-${MAX_PITCH - 1} only
- Use beats ${sectionStart} to ${sectionEnd - 1} only
- Create an interesting melodic/harmonic response — you're jamming with the user
- Vary rhythm and pitch. Don't just copy. React, complement, develop.
- Output ONLY a JSON array of objects: [{"pitch":number,"beat":number}]
- No explanation, no markdown fences, ONLY the JSON array`;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  
  const data = await res.json();
  const text = data.content?.map(b => b.text || "").join("") || "";
  const clean = text.replace(/```json|```/g, "").trim();
  const parsed = JSON.parse(clean);
  return parsed.map(n => ({
    pitch: Math.max(MIN_PITCH, Math.min(MAX_PITCH - 1, n.pitch)),
    beat: Math.max(sectionStart, Math.min(sectionEnd - 1, n.beat)),
    source: "ai",
  }));
};

export default function PingPongDAW() {
  const [notes, setNotes] = useState([]);
  const [currentSection, setCurrentSection] = useState(0);
  const [turn, setTurn] = useState("human"); // "human" | "ai" | "done"
  const [isPlaying, setIsPlaying] = useState(false);
  const [playPos, setPlayPos] = useState(-1);
  const [isGenerating, setIsGenerating] = useState(false);
  const [bpm, setBpm] = useState(BPM_DEFAULT);
  const [error, setError] = useState(null);
  const [history, setHistory] = useState([]);
  const synthRef = useRef(null);
  const playRef = useRef(null);
  const scrollRef = useRef(null);

  if (!synthRef.current) synthRef.current = createSynth();

  const sectionStart = currentSection * SECTION_BEATS;
  const sectionEnd = sectionStart + SECTION_BEATS;
  const humanSection = turn === "human" ? currentSection : -1;

  const hasNote = useCallback((pitch, beat) => {
    return notes.some(n => n.pitch === pitch && n.beat === beat);
  }, [notes]);

  const getNoteSource = useCallback((pitch, beat) => {
    const n = notes.find(n => n.pitch === pitch && n.beat === beat);
    return n?.source || null;
  }, [notes]);

  const toggleNote = useCallback((pitch, beat) => {
    if (turn !== "human") return;
    const sec = Math.floor(beat / SECTION_BEATS);
    if (sec !== currentSection) return;

    setNotes(prev => {
      const exists = prev.some(n => n.pitch === pitch && n.beat === beat);
      if (exists) {
        return prev.filter(n => !(n.pitch === pitch && n.beat === beat));
      }
      synthRef.current.playNote(pitch, 0.15, "human");
      return [...prev, { pitch, beat, source: "human" }];
    });
  }, [turn, currentSection]);

  const handleSendToAI = async () => {
    if (turn !== "human") return;
    const humanNotes = notes.filter(
      n => n.beat >= sectionStart && n.beat < sectionEnd && n.source === "human"
    );
    if (humanNotes.length === 0) {
      setError("まずノートを置いてください");
      setTimeout(() => setError(null), 2000);
      return;
    }

    setTurn("ai");
    setIsGenerating(true);
    setError(null);

    const nextSection = currentSection + 1;
    if (nextSection >= NUM_SECTIONS) {
      setIsGenerating(false);
      setTurn("done");
      setHistory(h => [...h, `セクション${currentSection + 1}: あなた (${humanNotes.length}ノート)`]);
      return;
    }

    const aiStart = nextSection * SECTION_BEATS;
    const aiEnd = aiStart + SECTION_BEATS;

    try {
      const aiNotes = await generateContinuation(notes, aiStart, aiEnd);
      setNotes(prev => [...prev, ...aiNotes]);
      setHistory(h => [
        ...h,
        `セクション${currentSection + 1}: あなた (${humanNotes.length}ノート)`,
        `セクション${nextSection + 1}: AI (${aiNotes.length}ノート)`,
      ]);
      setCurrentSection(nextSection + 1 < NUM_SECTIONS ? nextSection + 1 : nextSection);
      setTurn(nextSection + 1 < NUM_SECTIONS ? "human" : "done");
      
      // Auto-scroll to new section
      if (scrollRef.current) {
        const cellW = 28;
        scrollRef.current.scrollLeft = (nextSection + 1) * SECTION_BEATS * cellW - 40;
      }
    } catch (e) {
      setError(`AI生成エラー: ${e.message}`);
      setTurn("human");
    }
    setIsGenerating(false);
  };

  // Playback
  useEffect(() => {
    if (!isPlaying) {
      if (playRef.current) clearInterval(playRef.current);
      setPlayPos(-1);
      return;
    }
    const interval = (60 / bpm) * 1000;
    let beat = 0;
    const maxBeat = notes.length > 0 ? Math.max(...notes.map(n => n.beat)) + 1 : TOTAL_BEATS;
    
    setPlayPos(0);
    playRef.current = setInterval(() => {
      const currentBeat = beat;
      notes.filter(n => n.beat === currentBeat).forEach(n => {
        synthRef.current.playNote(n.pitch, interval / 1000 * 0.8, n.source);
      });
      beat++;
      if (beat > maxBeat) {
        setIsPlaying(false);
        return;
      }
      setPlayPos(beat);
    }, interval);
    
    // Play beat 0 immediately
    notes.filter(n => n.beat === 0).forEach(n => {
      synthRef.current.playNote(n.pitch, interval / 1000 * 0.8, n.source);
    });

    return () => { if (playRef.current) clearInterval(playRef.current); };
  }, [isPlaying, bpm, notes]);

  const clearCurrentSection = () => {
    if (turn !== "human") return;
    setNotes(prev => prev.filter(n => {
      const sec = Math.floor(n.beat / SECTION_BEATS);
      return sec !== currentSection || n.source !== "human";
    }));
  };

  const resetAll = () => {
    setNotes([]);
    setCurrentSection(0);
    setTurn("human");
    setIsPlaying(false);
    setHistory([]);
    setError(null);
  };

  // Chord labels for each bar
  const chords = [];
  for (let bar = 0; bar < BARS; bar++) {
    chords.push(detectChord(notes, bar * BEATS_PER_BAR));
  }

  const cellW = 28;
  const cellH = 14;
  const labelW = 42;

  return (
    <div style={{
      fontFamily: '"IBM Plex Mono", "SF Mono", "Fira Code", monospace',
      background: "#0a0a0b",
      color: "#e0ddd4",
      minHeight: "100vh",
      padding: "20px",
    }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "baseline", gap: 16, marginBottom: 6 }}>
        <h1 style={{ fontSize: 18, fontWeight: 600, color: "#f0ece0", margin: 0, letterSpacing: "0.08em" }}>
          PHASE:0
        </h1>
        <span style={{ fontSize: 12, color: "#6b6960", letterSpacing: "0.05em" }}>
          PING-PONG CO-CREATION PROTOTYPE
        </span>
      </div>
      <div style={{ fontSize: 11, color: "#4a473f", marginBottom: 20, letterSpacing: "0.03em" }}>
        AIは共演者であって、プロデューサーではない
      </div>

      {/* Transport + Controls */}
      <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 16, flexWrap: "wrap" }}>
        <button
          onClick={() => { synthRef.current.getCtx(); setIsPlaying(!isPlaying); }}
          style={{
            background: isPlaying ? "#e24b4a" : "#1d9e75",
            color: "#0a0a0b",
            border: "none",
            padding: "6px 18px",
            fontSize: 12,
            fontWeight: 600,
            fontFamily: "inherit",
            cursor: "pointer",
            letterSpacing: "0.05em",
          }}
        >
          {isPlaying ? "■ STOP" : "▶ PLAY"}
        </button>
        
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={{ fontSize: 11, color: "#6b6960" }}>BPM</label>
          <input
            type="number"
            value={bpm}
            onChange={e => setBpm(Math.max(40, Math.min(300, +e.target.value)))}
            style={{
              width: 50, background: "#1a1a1c", border: "1px solid #2a2a2d",
              color: "#e0ddd4", padding: "4px 6px", fontSize: 12, fontFamily: "inherit",
            }}
          />
        </div>

        <div style={{ flex: 1 }} />

        <button
          onClick={clearCurrentSection}
          disabled={turn !== "human"}
          style={{
            background: "transparent", border: "1px solid #2a2a2d", color: "#6b6960",
            padding: "5px 14px", fontSize: 11, fontFamily: "inherit", cursor: "pointer",
            opacity: turn !== "human" ? 0.3 : 1,
          }}
        >
          CLEAR SECTION
        </button>
        <button
          onClick={resetAll}
          style={{
            background: "transparent", border: "1px solid #2a2a2d", color: "#6b6960",
            padding: "5px 14px", fontSize: 11, fontFamily: "inherit", cursor: "pointer",
          }}
        >
          RESET ALL
        </button>
      </div>

      {/* Status bar */}
      <div style={{
        display: "flex", alignItems: "center", gap: 12, marginBottom: 12,
        padding: "8px 12px", background: "#111113", fontSize: 12,
      }}>
        <span style={{ color: "#6b6960" }}>SECTION</span>
        <span style={{ color: "#f0ece0", fontWeight: 600 }}>
          {turn === "done" ? "完了" : `${currentSection + 1} / ${NUM_SECTIONS}`}
        </span>
        <span style={{ color: "#2a2a2d" }}>│</span>
        <span style={{ color: "#6b6960" }}>TURN</span>
        <span style={{
          color: turn === "human" ? "#ef9f27" : turn === "ai" ? "#5dcaa5" : "#6b6960",
          fontWeight: 600,
        }}>
          {turn === "human" ? "あなた" : turn === "ai" ? "AI" : "---"}
        </span>
        <span style={{ color: "#2a2a2d" }}>│</span>
        <span style={{ color: "#6b6960" }}>NOTES</span>
        <span style={{ color: "#f0ece0" }}>
          {notes.filter(n => n.source === "human").length}H / {notes.filter(n => n.source === "ai").length}AI
        </span>
        {error && (
          <>
            <span style={{ color: "#2a2a2d" }}>│</span>
            <span style={{ color: "#e24b4a", fontSize: 11 }}>{error}</span>
          </>
        )}
      </div>

      {/* Chord labels */}
      <div style={{ display: "flex", marginLeft: labelW, marginBottom: 2, overflow: "hidden" }}>
        <div ref={scrollRef} style={{
          display: "flex", overflowX: "auto", scrollBehavior: "smooth",
          msOverflowStyle: "none", scrollbarWidth: "none",
        }}>
          {chords.map((chord, bar) => {
            const sec = Math.floor(bar / SECTION_BARS);
            const isHumanSec = notes.some(n => Math.floor(n.beat / SECTION_BEATS) === sec && n.source === "human");
            const isAISec = notes.some(n => Math.floor(n.beat / SECTION_BEATS) === sec && n.source === "ai");
            return (
              <div key={bar} style={{
                width: cellW * BEATS_PER_BAR,
                minWidth: cellW * BEATS_PER_BAR,
                textAlign: "center",
                fontSize: 10,
                fontWeight: 600,
                color: chord ? (isAISec ? "#5dcaa5" : isHumanSec ? "#ef9f27" : "#6b6960") : "#2a2a2d",
                borderLeft: bar % SECTION_BARS === 0 ? "1px solid #3a3a3d" : "none",
                letterSpacing: "0.02em",
              }}>
                {chord || "·"}
              </div>
            );
          })}
        </div>
      </div>

      {/* Piano Roll */}
      <div style={{ display: "flex" }}>
        {/* Pitch labels */}
        <div style={{ width: labelW, flexShrink: 0 }}>
          {Array.from({ length: PITCH_COUNT }, (_, i) => {
            const pitch = MAX_PITCH - 1 - i;
            const black = isBlackKey(pitch);
            return (
              <div key={pitch} style={{
                height: cellH,
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-end",
                paddingRight: 6,
                fontSize: 9,
                color: pitch % 12 === 0 ? "#e0ddd4" : black ? "#4a473f" : "#6b6960",
                fontWeight: pitch % 12 === 0 ? 600 : 400,
              }}>
                {pitchToName(pitch)}
              </div>
            );
          })}
        </div>

        {/* Grid */}
        <div style={{
          flex: 1,
          overflowX: "auto",
          msOverflowStyle: "none",
          scrollbarWidth: "thin",
          scrollbarColor: "#2a2a2d #111113",
        }}
        onScroll={e => {
          if (scrollRef.current) scrollRef.current.scrollLeft = e.target.scrollLeft;
        }}
        >
          <div style={{ position: "relative", width: cellW * TOTAL_BEATS, height: cellH * PITCH_COUNT }}>
            {/* Section backgrounds */}
            {Array.from({ length: NUM_SECTIONS }, (_, sec) => {
              const isCurrentHuman = sec === currentSection && turn === "human";
              const hasAI = notes.some(n => Math.floor(n.beat / SECTION_BEATS) === sec && n.source === "ai");
              const hasHuman = notes.some(n => Math.floor(n.beat / SECTION_BEATS) === sec && n.source === "human");
              let bg = "#0e0e10";
              if (isCurrentHuman) bg = "#1a170e";
              else if (hasAI) bg = "#0e1614";
              else if (hasHuman) bg = "#14120c";
              return (
                <div key={sec} style={{
                  position: "absolute",
                  left: sec * SECTION_BEATS * cellW,
                  top: 0,
                  width: SECTION_BEATS * cellW,
                  height: cellH * PITCH_COUNT,
                  background: bg,
                  borderLeft: "1px solid #3a3a3d",
                  borderRight: sec === NUM_SECTIONS - 1 ? "1px solid #3a3a3d" : "none",
                  boxSizing: "border-box",
                }} />
              );
            })}

            {/* Grid lines */}
            {Array.from({ length: TOTAL_BEATS }, (_, beat) => (
              <div key={`vl${beat}`} style={{
                position: "absolute",
                left: beat * cellW,
                top: 0,
                width: 1,
                height: cellH * PITCH_COUNT,
                background: beat % BEATS_PER_BAR === 0 ? "#2a2a2d" : "#18181b",
              }} />
            ))}
            {Array.from({ length: PITCH_COUNT }, (_, i) => {
              const pitch = MAX_PITCH - 1 - i;
              return (
                <div key={`hl${i}`} style={{
                  position: "absolute",
                  left: 0,
                  top: i * cellH,
                  width: cellW * TOTAL_BEATS,
                  height: 1,
                  background: pitch % 12 === 0 ? "#2a2a2d" : isBlackKey(pitch) ? "#111113" : "#18181b",
                }} />
              );
            })}

            {/* Playback cursor */}
            {playPos >= 0 && (
              <div style={{
                position: "absolute",
                left: playPos * cellW,
                top: 0,
                width: 2,
                height: cellH * PITCH_COUNT,
                background: "#f0ece0",
                opacity: 0.6,
                zIndex: 20,
                pointerEvents: "none",
              }} />
            )}

            {/* Clickable cells */}
            {Array.from({ length: PITCH_COUNT }, (_, row) => {
              const pitch = MAX_PITCH - 1 - row;
              return Array.from({ length: TOTAL_BEATS }, (_, beat) => {
                const has = hasNote(pitch, beat);
                const source = getNoteSource(pitch, beat);
                const sec = Math.floor(beat / SECTION_BEATS);
                const canEdit = turn === "human" && sec === currentSection;
                
                return (
                  <div
                    key={`${row}-${beat}`}
                    onClick={() => toggleNote(pitch, beat)}
                    style={{
                      position: "absolute",
                      left: beat * cellW + 1,
                      top: row * cellH + 1,
                      width: cellW - 2,
                      height: cellH - 2,
                      background: has
                        ? source === "ai" ? "#1d9e75" : "#ef9f27"
                        : "transparent",
                      opacity: has ? 1 : 1,
                      cursor: canEdit ? "pointer" : "default",
                      borderRadius: 2,
                      transition: "background 0.08s",
                      zIndex: 10,
                    }}
                    onMouseEnter={e => {
                      if (canEdit && !has) e.target.style.background = "#ef9f2730";
                    }}
                    onMouseLeave={e => {
                      if (!has) e.target.style.background = "transparent";
                    }}
                  />
                );
              });
            })}

            {/* Section labels at bottom */}
            {Array.from({ length: NUM_SECTIONS }, (_, sec) => {
              const hasAI = notes.some(n => Math.floor(n.beat / SECTION_BEATS) === sec && n.source === "ai");
              const hasHuman = notes.some(n => Math.floor(n.beat / SECTION_BEATS) === sec && n.source === "human");
              return (
                <div key={`sl${sec}`} style={{
                  position: "absolute",
                  left: sec * SECTION_BEATS * cellW,
                  bottom: -22,
                  width: SECTION_BEATS * cellW,
                  textAlign: "center",
                  fontSize: 9,
                  color: hasAI ? "#5dcaa5" : hasHuman ? "#ef9f27" : "#4a473f",
                  letterSpacing: "0.05em",
                }}>
                  {hasAI ? "AI" : hasHuman ? "YOU" : sec === currentSection && turn === "human" ? "→ YOU" : `SEC ${sec + 1}`}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Action area */}
      <div style={{ marginTop: 36, display: "flex", gap: 12, alignItems: "center" }}>
        {turn === "human" && (
          <button
            onClick={handleSendToAI}
            disabled={isGenerating}
            style={{
              background: isGenerating ? "#2a2a2d" : "#ef9f27",
              color: "#0a0a0b",
              border: "none",
              padding: "10px 28px",
              fontSize: 13,
              fontWeight: 600,
              fontFamily: "inherit",
              cursor: isGenerating ? "wait" : "pointer",
              letterSpacing: "0.05em",
            }}
          >
            {isGenerating ? "AI THINKING..." : "AIに渡す →"}
          </button>
        )}
        {turn === "ai" && isGenerating && (
          <div style={{
            padding: "10px 28px",
            fontSize: 13,
            color: "#5dcaa5",
            border: "1px solid #1d9e75",
            display: "flex",
            alignItems: "center",
            gap: 10,
          }}>
            <span style={{ animation: "pulse 1s infinite", display: "inline-block" }}>●</span>
            AIがフレーズを考えています...
          </div>
        )}
        {turn === "done" && (
          <div style={{ fontSize: 13, color: "#6b6960" }}>
            セッション完了。PLAYで通して聴いてみてください。
          </div>
        )}
      </div>

      {/* Session log */}
      {history.length > 0 && (
        <div style={{ marginTop: 20, padding: "12px 16px", background: "#111113", fontSize: 11 }}>
          <div style={{ color: "#4a473f", marginBottom: 6, letterSpacing: "0.05em" }}>SESSION LOG</div>
          {history.map((entry, i) => (
            <div key={i} style={{
              color: entry.includes("AI") ? "#5dcaa5" : "#ef9f27",
              marginBottom: 2,
            }}>
              {entry}
            </div>
          ))}
        </div>
      )}

      {/* Instructions */}
      <div style={{
        marginTop: 20,
        padding: "12px 16px",
        background: "#111113",
        fontSize: 11,
        color: "#4a473f",
        lineHeight: 1.8,
      }}>
        <span style={{ color: "#6b6960", letterSpacing: "0.05em" }}>HOW TO JAM</span>
        <br />
        <span style={{ color: "#ef9f27" }}>■</span> あなたのセクション（黄色）にノートを置く → 
        <span style={{ color: "#ef9f27" }}>「AIに渡す」</span> → 
        <span style={{ color: "#5dcaa5" }}>■</span> AIが次のセクションを書く → 繰り返し
        <br />
        4小節ずつ交互に。あなたが始めて、AIが応える。全16小節でセッション完了。
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.3; }
        }
        ::-webkit-scrollbar { height: 6px; }
        ::-webkit-scrollbar-track { background: #111113; }
        ::-webkit-scrollbar-thumb { background: #2a2a2d; }
      `}</style>
    </div>
  );
}
